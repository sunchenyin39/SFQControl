# SFQContol Python Package
# Functions:
1.Using Genetic Algorithm to find the best SFQ pulse sequence realizing target quantum gate 